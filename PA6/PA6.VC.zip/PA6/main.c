#include "battleship.h"

int main(void)
{
	char player_one_board[NUM_ROWS][NUM_COLUMNS] = { {'~'} };

	int placement = 0;
	Dir direct = VERTICAL;
	int *x_begin = 0, *y_begin = 0;
	int occupied = 0;

	welcome_screen();
	press_enter();
	initialize_game_board(player_one_board, NUM_ROWS, NUM_COLUMNS);
	print_game_board(player_one_board, NUM_ROWS, NUM_COLUMNS);
	placement = ship_placement_menu();
	direct = get_manual_direction();

	generate_start_manual(CARRIER, direct, &x_begin, &y_begin);
	printf("\n%d %d\n", x_begin, y_begin); //checking

	place_ship(player_one_board, CARRIER, direct, x_begin, y_begin, CAR);
	
	

	do
	{
		generate_start_manual(BATTLESHIP, direct, &x_begin, &y_begin);
		occupied = prevent_overwrite(player_one_board, BATTLESHIP, direct, x_begin, y_begin);
		if (occupied == 0) { place_ship(player_one_board, BATTLESHIP, direct, x_begin, y_begin, BAT); }
		
	} while (occupied != 0);

	
	






	//while (placement == MANUAL)
	//{
		//place c, b, r, s, d
		//check_carrier_location(player_one_board);
		//check_battleship_location(player_one_board);
		print_game_board(player_one_board, NUM_ROWS, NUM_COLUMNS);
	//}
}


/*do
{
printf("Choose starting location (x,y): ");
scanf("%d", &x_start);
scanf("%d", &y_start);
} while (x_start < 0 || x_start > 9 || y_start < 0 || y_start > 9);*/

/*printf("Enter five cells to place the Carrier (x,y): ");
for (i = 0; i < CARRIER; ++i)
{
scanf("%d", x_carrier);
scanf("%d", y_carrier);
}

for (i = 0; i < NUM_ROWS; ++i)
{
if (x_carrier[i] == i)
{
row_counter[i] += 1;
}
}

for (i = 0; i < NUM_COLUMNS; ++i)
{
if (y_carrier[i] == i)
{
cols_counter[i] += 1;
}
}

for (i = 0; i < NUM_ROWS; ++i)
{
if (row_counter[i] != CARRIER)
{
printf("Invalid Horizontal Placement\n");
}
}*/