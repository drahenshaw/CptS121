#include "battleship.h"

void welcome_screen(void)
{
	printf("* * * * * * * * * * * * * * * * * * * *WELCOME TO BATTLESHIP* * * * * * * * * * * * * * * * * * * *\n");
	printf("* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\n");
	printf("* * * * * * * * * * * ** * * * *  * * * RULES OF BATTLESHIP * * * * * * * * * * * * * * * * * * * *\n");
	putchar('\n');
	printf("Battleship is a player vs player Naval warship game where the objective is to sink the enemy fleet.\n");
	printf("Each fleet consists of five ships, Carrier, Battleship, Submarine, Destroyer, and Crusier.\n");
	printf("Each ship occupies the following number of cells on a 10 x 10 game board:\n");
	printf(" 1. Carrier - 5\n 2. Battleship - 4\n 3. Submarine - 3\n 4. Destroyer - 3\n 5. Crusier - 2\n\n");
	printf("* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\n");
	printf("\nThe player fires shot at a (x,y) location to try and hit the enemy ships\n");
	printf("Hits and misses are marked on the game board.\n");
	printf("When all cells of a ship are hit, the ship sinks. The player to sink all five ships first wins!\n\n");
	printf("* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\n");
	printf("\nThe player whose turn is first is selected at random. Ships may be placed randomly or manually.\n");
	printf("Ships may only be placed vertically or horizontally, not diagonally.\n\n");
	printf("* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\n");
	printf("* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\n");
}

void press_enter(void)
{
	printf("Press any key to Continue\n");
	getch();
	system("cls");
}

void initialize_rand(void)
{
	srand(time(NULL));
}

void initialize_game_board(char board[][NUM_COLUMNS], int rows, int cols)
{
	int i = 0, j = 0;

	for (i = 0; i < rows; ++i)
	{
		for (j = 0; j < cols; ++j)
		{
			board[i][j] = '~';
		}
	}
}

void print_game_board(char board[][NUM_COLUMNS], int rows, int cols)
{
	int i = 0, j = 0;
	printf("Row:\n");
	for (i = 0; i < rows; ++i)
	{	
		printf("%d.\t", i);
		for (j = 0; j < cols; ++j)
		{
			printf("%c ", board[i][j]);
		}
		putchar('\n');
	}
	putchar('\n');
	printf("Col:    0.1.2.3.4.5.6.7.8.9.\n\n");
}

void display_menu(void)
{
	printf("1. Place Fleet Manually?\n");
	printf("2. Place Ships Randomly?\n");	
}

int menu_input(void)
{
	int option = 0;
	scanf("%d", &option);
	return option;
}

int ship_placement_menu(void)
{
	int option = 0;
	do //Repeats when input is not in the integer range of 1 - 2
	{
		display_menu();
		option = menu_input();
		system("cls");
	} while (option < MANUAL || option > RANDOM);
	return option;
}

Dir get_random_direction(void)
{
	Dir direction = VERTICAL;

	direction = rand() % 2;
	return direction;
}

Dir get_manual_direction(void)
{
	Dir direction = VERTICAL;
	
	do
	{
		printf("Choose a direction:\n0.Vertical\t1.Horizontal\n");
		scanf("%d", &direction);
	} while (direction < VERTICAL || direction > HORIZONTAL);
	return direction;
}

//void get_carrier_location()
	//get direction
		//if vertical or horizontal
	//starting location
	//check validity 

void generate_start_manual(int ship_length, Dir direction, int *x_start, int *y_start)
{
	int x = 0, y = 0, flag = 0;

	if (direction == VERTICAL)
	{
		do
		{
			flag = 0;
			printf("Choose starting row to place ship: ");
			scanf("%d", &x);
			printf("Choose starting column to place ship: ");
			scanf("%d", &y);

			if ((x + ship_length - 1) >= 9 || y > 9 || x < 0 || y < 0)
			{
				printf("Invalid ship placement: ship must be inbounds.\n");
				printf("Please try again!\n");
				flag = 1;
			}
		} while (flag == 1);
	}

	if (direction == HORIZONTAL)
	{
		do
		{
			flag = 0;
			printf("Choose starting row to place ship: ");
			scanf("%d", &x);
			printf("Choose starting column to place ship: ");
			scanf("%d", &y);

			if ((y + ship_length - 1) >= 9 || x > 9 || x < 0 || y < 0)
			{
				printf("Invalid ship placement: ship must be inbounds.\n");
				printf("Please try again!\n");
				flag = 1;
			}
		} while (flag == 1);
	}

	*x_start = x;
	*y_start = y;
}

void place_ship(char board[][NUM_COLUMNS], int ship_length, Dir direction, int x_start, int y_start, Ship ship)
{
	int i = x_start, j = y_start;

	if (direction == VERTICAL)
	{
		for (i = x_start; i < (ship_length + x_start); ++i)
		{
			switch (ship)
			{
			case CAR: board[i][j] = 'c';
				break;
			case BAT: board[i][j] = 'b';
				break;
			case SUB: board[i][j] = 's';
				break;
			case DES: board[i][j] = 'd';
				break;
			case CRU: board[i][j] = 'r';
				break;
			}
		}
	}
	else //horizontal
	{
		for (j = y_start; j < (ship_length + y_start); ++j)
		{
			switch (ship)
			{
			case CAR: board[i][j] = 'c';
				break;
			case BAT: board[i][j] = 'b';
				break;
			case SUB: board[i][j] = 's';
				break;
			case DES: board[i][j] = 'd';
				break;
			case CRU: board[i][j] = 'r';
				break;
			}
		}
	}
	
}

int prevent_overwrite(char board[][NUM_COLUMNS], int ship_length, Dir direction, int x_start, int y_start)
{
	int i = x_start, j = y_start;	
	
	if (direction == VERTICAL)
		{
			for (i = x_start; i < (x_start + ship_length); i += 1);
			{
				if (board[i][y_start] != '~')
				{
					printf("Space already occupied, please try again\n");
					return 1;
				}
			}
		}
	else //HORIZONTAL
		{
			for (j = y_start; i < (y_start + ship_length); ++j);
			{
				if (board[x_start][j] != '~')
				{
					printf("Space already occupied, please try again\n");
					return 1;
				}
			}
		}
	return 0;
}

	/**********************************************************************************************************************************************************************************************************************/
		/*UNUSED FUNCTIONS*/
	/**********************************************************************************************************************************************************************************************************************/

void initialize_ship_array(int ship[], int size)
{
	int i = 0;

	for (i = 0; i < size; ++i)
	{
		ship[i] = -1;
	}
}

void counter(int array[], int counter[], int size)
{
	int i = 0, j = 0;

	for (i = 0; i < size; ++i)
	{
		for (j = 0; j < NUM_ROWS; ++j)
		{
			if (array[i] == j)
			{
				counter[j] += 1;
			}
		}
	}
}

void get_carrier_location(int xarray[], int yarray[])
{
	int i = 0;

	printf("Enter five cells to place the Carrier (x,y): ");
	for (i = 0; i < CARRIER; ++i)
	{
	scanf("%d", &xarray[i]);
	scanf("%d", &yarray[i]);
	}
}

void check_carrier_location(char board[][NUM_COLUMNS])
{
	int i = 0, j = 0, flag = 0;
	int x_carrier[CARRIER] = { 0 }; //Stores x locations for carrier
	int y_carrier[CARRIER] = { 0 }; //Stores y locations for carrier
	int row_counter[NUM_ROWS] = { 0 };
	int cols_counter[NUM_COLUMNS] = { 0 };

	Dir direction = get_manual_direction();
	initialize_ship_array(x_carrier, CARRIER);
	initialize_ship_array(y_carrier, CARRIER);
		
	if (direction == VERTICAL)
	{
		do
		{
			flag = 0;
			get_carrier_location(x_carrier, y_carrier);
			//counter(y_carrier, cols_counter, CARRIER);
			for (i = 0; i < CARRIER - 1; i++)
			{
				if (y_carrier[i] != y_carrier[i + 1])
				{
					flag = 1;
				}
			}
			if (flag = 1)
			{
				printf("Invalid Vertical Placement: Columns must be the same\n");
			}
		} while (flag == 1);
	}
		
	if (direction == HORIZONTAL)
	{
		do
		{
			get_carrier_location(x_carrier, y_carrier);
			counter(x_carrier, row_counter, CARRIER);
			for (i = 0; i < NUM_ROWS; i++)
			{
				if (row_counter[i] == 5)
				{
					flag = 1;
				}
			}
			if (flag = 0)
			{
				printf("Invalid Horizontal Placement: Rows must be the same\n");
			}
		} while (flag == 1);
	}	
	
	for (i = 0; i < CARRIER; ++i)
	{
		board[x_carrier[i]][y_carrier[i]] = 'c';
	}
}

void get_battleship_location(int xarray[], int yarray[])
{
	int i = 0;

	printf("Enter four cells to place the Battleship (x,y): ");
	for (i = 0; i < BATTLESHIP; ++i)
	{
		scanf("%d", &xarray[i]);
		scanf("%d", &yarray[i]);
	}
}

void check_battleship_location(char board[][NUM_COLUMNS])
{
	int i = 0, j = 0, flag = 0;
	int x_battleship[NUM_ROWS] = { 0 };
	int y_battleship[NUM_COLUMNS] = { 0 };
	int row_counter[BATTLESHIP] = { 0 };
	int cols_counter[BATTLESHIP] = { 0 };

	Dir direction = get_manual_direction();
	initialize_ship_array(x_battleship, NUM_ROWS);
	initialize_ship_array(y_battleship, NUM_COLUMNS);

	if (direction == VERTICAL)
	{
		do
		{
			get_battleship_location(x_battleship, y_battleship);
			counter(y_battleship, cols_counter, BATTLESHIP);
			for (i = 0; i < NUM_COLUMNS; i++)
			{
				if (cols_counter[i] == 5)
				{
					flag = 1;
				}
			}
			if (flag = 0)
			{
				printf("Invalid Vertical Placement: Columns must be the same\n");
			}
		} while (flag == 1);
	}

	if (direction == HORIZONTAL)
	{
		do
		{
			get_battleship_location(x_battleship, y_battleship);
			counter(x_battleship, row_counter, BATTLESHIP);
			for (i = 0; i < NUM_ROWS; i++)
			{
				if (row_counter[i] == 5)
				{
					flag = 1;
				}
			}
			if (flag = 0)
			{
				printf("Invalid Horizontal Placement: Rows must be the same\n");
			}
		} while (flag == 1);
	}

	for (i = 0; i < BATTLESHIP; ++i)
	{
		board[x_battleship[i]][y_battleship[i]] = 'b';
	}
}
