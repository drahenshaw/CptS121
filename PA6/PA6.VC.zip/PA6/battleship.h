#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

#define NUM_ROWS 10
#define NUM_COLUMNS 10
#define MANUAL 1
#define RANDOM 2
#define CARRIER 5
#define BATTLESHIP 4
#define SUBMARINE 3
#define DESTROYER 3
#define CRUSIER 2

typedef enum Dir
{
	VERTICAL, HORIZONTAL
}Dir;

typedef enum Ship
{
	CAR, BAT, SUB, DES, CRU
}Ship;

void welcome_screen(void);
void press_enter(void);
void initialize_rand(void);
void initialize_game_board(char board[][NUM_COLUMNS], int rows, int cols);
void print_game_board(char board[][NUM_COLUMNS], int rows, int cols);
void display_menu(void);
int menu_input(void);
int ship_placement_menu(void);
Dir get_random_direction(void);
Dir get_manual_direction(void);
void initialize_ship_array(int ship[], int size);
void counter(int array[], int counter[], int size);
void get_carrier_location(int xarray[], int yarray[]);
void check_carrier_location(char board[][NUM_COLUMNS]);
void get_battleship_location(int xarray[], int yarray[]);
void check_battleship_location(char board[][NUM_COLUMNS]);


void generate_start_manual(int ship_length, Dir direction, int *x_start, int *y_start);
void place_ship(char board[][NUM_COLUMNS], int ship_length, Dir direction, int x_start, int y_start, Ship ship);
int prevent_overwrite(char board[][NUM_COLUMNS], int ship_length, Dir direction, int x_start, int y_start);
